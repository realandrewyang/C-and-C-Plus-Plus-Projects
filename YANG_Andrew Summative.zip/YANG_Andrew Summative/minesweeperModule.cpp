/***************************************************
* Name: Andrew Yang                                *
* Course: ICS3U                                    *
* Teacher: Ms. Cullum                              *
* Date: December 4 2017                            *
*                                                  *
* This file declares all the important functions   *
* for the minesweeper game. Loose coupling was     *
* attempted where possible.                        *
****************************************************/

// Declaring functions

// This function loads the main menu of the game
int loadMainMenu(int SCREEN_W, int SCREEN_H){

    // Initialize pointers
    ALLEGRO_DISPLAY *display = nullptr;
    ALLEGRO_EVENT_QUEUE *event_queue = nullptr;
    ALLEGRO_MOUSE_STATE mouse;
    FILE *fptr = nullptr;

    // Load fonts
    ALLEGRO_FONT *font = al_load_ttf_font("Ikaros-Regular.otf", 50, 0);
    ALLEGRO_FONT *otherFont = al_load_ttf_font("Ikaros-Light.otf", 20, 0);
    ALLEGRO_FONT *smallFont = al_load_ttf_font("Ikaros-Light.otf", 12, 0);


    // Declare and initialize variables
    int referenceX = SCREEN_W / 4;
    int referenceY = SCREEN_H / 2 + 20;
    char instruction[79][20];
    char temp[20] = "";
    bool escape = false;

    // Create display
    display = al_create_display(SCREEN_W, SCREEN_H);
	if (!display) {
    	al_show_native_message_box(display, "Error", "Error", "Failed to initialize display!",
                                 nullptr, ALLEGRO_MESSAGEBOX_ERROR);
       	return -1;
	}

	// Initialize primative add on
 	if (!al_init_primitives_addon()) {
    	al_show_native_message_box(display, "Error", "Error", "Failed to initialize primatives addon!",
                                 nullptr, ALLEGRO_MESSAGEBOX_ERROR);
    	return -1;
	}

    // Initialize fonts, install mouse, create event queue, register event sources, and open instruction file
    al_init_font_addon();
    al_init_ttf_addon();
    al_install_mouse();
    event_queue = al_create_event_queue();
    al_register_event_source(event_queue, al_get_mouse_event_source());
    al_register_event_source(event_queue, al_get_display_event_source(display));
    fptr = fopen("Instructions.txt", "r");

    if (!font){
       al_show_native_message_box(display, "Error", "Error", "Could not load Ikaros-Regular.otf",
                                     nullptr, ALLEGRO_MESSAGEBOX_ERROR);
       return -1;
    }
    if (!otherFont || !smallFont){
       al_show_native_message_box(display, "Error", "Error", "Could not load Ikaros-Light.otf",
                                     nullptr, ALLEGRO_MESSAGEBOX_ERROR);
       return -1;
    }
    if (!fptr){
        al_show_native_message_box(display, "Error", "Error", "Could not load Instructions.txt",
                                     nullptr, ALLEGRO_MESSAGEBOX_ERROR);
       return -1;
    }


	// Create window with background colour, titles and "Play" button
	al_set_window_title(display, "MineSweeper");
	al_draw_filled_rectangle(0, 0, SCREEN_W, SCREEN_H, WHITE);
    al_clear_to_color(WHITE);
    al_draw_text(font, BLACK, (SCREEN_W/2), (SCREEN_H/6), ALLEGRO_ALIGN_CENTRE, "Minesweeper");
    al_draw_text(otherFont, BLACK, (SCREEN_W/2), (SCREEN_H/6 + 60), ALLEGRO_ALIGN_CENTRE, "By Andrew Yang");
    al_draw_text(otherFont, BLACK, (SCREEN_W/2), (2 * SCREEN_H/5 + 10), ALLEGRO_ALIGN_CENTRE, "Play");
    al_draw_rectangle(SCREEN_W/4 , 2 * SCREEN_H/5 , 3 * SCREEN_W/4, 2 * SCREEN_H/5 + 50, BLACK, 1);

    // Display instructions
    for (int i = 0; i < 78; i++){

        // Take instructions word by word from the text file and place each word in a temporary string
        fscanf(fptr, "%s", instruction[i]);
        strcpy(temp, instruction[i]);
        al_draw_text(smallFont, BLACK, referenceX, referenceY, ALLEGRO_ALIGN_LEFT, temp);

        // Move the reference point over for the next word, and skip a line when the margin is reached
        referenceX+= 7 * (strlen(instruction[i]) + 1);
        if (referenceX + 7 * (strlen(instruction[i + 1])) >= 3 * SCREEN_W / 4){
            referenceY+= 16;
            referenceX = SCREEN_W / 4;
        }
    }

    al_flip_display();

    // Wait for the user to click on "Play"
    while (!escape){

        // Create event
        ALLEGRO_EVENT ev;
        al_wait_for_event(event_queue, &ev);

        // Obtain mouse coordinates whenever the mouse is released
        if (ev.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP){
            al_get_mouse_state(&mouse);

            int xCoord = mouse.x;
            int yCoord = mouse.y;

            // Check if user releases mouse click within the location of the "Play" button
            if (xCoord > SCREEN_W/4 && xCoord < 3 * SCREEN_W/4 && yCoord > 2 * SCREEN_H/5 && yCoord < 2 * SCREEN_H/5 + 50){
                escape = true;
            }
        } else if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE){
            al_destroy_display(display);
            return 2;
        }
    }

    // Close file and destroy display
    fclose(fptr);
    al_destroy_display(display);
    return 0;
}

// This function loads the in-game screen
int loadGame(int rowLength, int columnLength, Square squares[][N], int numOfMines){
    if (loadMines(rowLength, columnLength, squares, numOfMines) == -1){
        return -1;
    }

    // TO BE COMPLETED
}

// This function loads the mines in each square
int loadMines(int rowLength, int columnLength, Square squares[][N], int numOfMines){
    // Check if there are more mines than squares
    if (rowLength * columnLength < numOfMines){
        return -1;
    }

    // Declare and initialize variables
    int randValueX, randValueY = 0;

    // Load the mines
    for (int i = 0; i < numOfMines; i++){
        randValueX = rand() % rowLength;
        randValueY = rand() % columnLength;

        // Ensure that a square is not loaded with mines twice
        while (squares[randValueX][randValueY].value == -1){
            randValueX = rand() % rowLength;
            randValueY = rand() % columnLength;
        }

        // Assign -1 to indicate a mine
        squares[randValueX][randValueY].value = -1;
    }

    return 0;
}

/* This function loads the values inside each square,
   which means the number of mines around it. It
   sweeps through a maximum of eight squares around it
   to check for mines. */
void loadMineCheck(int rowLength, int columnLength, Square squares[][N]){
    for (int i = 0; i < rowLength; i++){
        for (int j = 0; j < columnLength ; j++){

            // Integers k and l act as navigators around the square
            for (int k = -1; k <= 1; k++){
                for (int l = -1; l <= 1; l++){

                    // Check to make sure the home square itself is not being scanned
                    if (k != 0 || l != 0){

                        // Check to see if the square being scanned exists
                        if (validCoord(i + k, j + l, rowLength, columnLength)){
                            mineCheck(squares[i][j], squares[i + k][j + l]);
                        }
                    }
                }
            }
        }
    }
}

/* This function adds one to the value of "homeSquare" if "checkSquare" contains a mine */
void mineCheck(Square &homeSquare, Square &checkSquare){
    if (homeSquare.value != -1){
        if (checkSquare.value == -1){
            homeSquare.value++;
        }
    }
}

/* This function checks if a certain square's indices exists in the total array of squares,
   which is useful for avoiding out of bound errors */
bool validCoord(int xCoord, int yCoord, int xMax, int yMax){
    if (xCoord >= 0 && xCoord < xMax && yCoord >= 0 && yCoord < yMax){
        return true;
    }
    return false;
}

// This function converts an integer to a character
char numToChar(int num){
    char output = ' ';
    switch (num){
        case 0:
            output = '0';
            break;
        case 1:
            output = '1';
            break;
        case 2:
            output = '2';
            break;
        case 3:
            output = '3';
            break;
        case 4:
            output = '4';
            break;
        case 5:
            output = '5';
            break;
        case 6:
            output = '6';
            break;
        case 7:
            output = '7';
            break;
        case 8:
            output = '8';
            break;
        case 9:
            output = '9';
            break;
        default:
            output = ' ';
    }
    return output;
}

// This function reveals a square and recursively reveals all squares around it if none of them contain mines
void checkSquare(Square allSquares[][N], int xCoord, int yCoord, const ALLEGRO_FONT* font, ALLEGRO_COLOR color, int &squaresLeft){

    // Declare a string to store the number that will be displayed
    char squareValue[2] = "";
    squareValue[0] = numToChar(allSquares[xCoord][yCoord].value);

    // Indicate that the square has been checked
    allSquares[xCoord][yCoord].isChecked = true;
    squaresLeft--;

    // Reveal the square and the number behind it
    al_draw_filled_rectangle(allSquares[xCoord][yCoord].topLeft.xCoord, allSquares[xCoord][yCoord].topLeft.yCoord, allSquares[xCoord][yCoord].topLeft.xCoord + 20, allSquares[xCoord][yCoord].topLeft.yCoord + 20, WHITE);
    al_draw_rectangle(allSquares[xCoord][yCoord].topLeft.xCoord, allSquares[xCoord][yCoord].topLeft.yCoord, allSquares[xCoord][yCoord].topLeft.xCoord + 20, allSquares[xCoord][yCoord].topLeft.yCoord + 20, BLACK, 1);

    // Reveal the number of the square if it is not a mine
    if (allSquares[xCoord][yCoord].value > 0){
        al_draw_text(font, BLACK, allSquares[xCoord][yCoord].topLeft.xCoord + 5, allSquares[xCoord][yCoord].topLeft.yCoord + 3, ALLEGRO_ALIGN_LEFT, squareValue);
    }

    // Reveal a mine if the value is -1, and immediately terminate the game by setting the number of squares left to -1
    if (allSquares[xCoord][yCoord].value == -1){
        squaresLeft = -1;
        al_draw_filled_circle(allSquares[xCoord][yCoord].topLeft.xCoord + 10, allSquares[xCoord][yCoord].topLeft.yCoord + 10, 5, BLACK);
    } else if (!(minesAround(allSquares,xCoord, yCoord, 10, 10))){
        // Recursively check the mines around the selected square if none of them contain mines

        for (int i = -1; i <= 1; i++){
            for (int j = -1; j <= 1; j++){
                if (validCoord(xCoord + i, yCoord + j, 10, 10) && !(i == 0 && j == 0) && !allSquares[xCoord + i][yCoord + j].isChecked && !allSquares[xCoord + i][yCoord + j].isMarked){
                    checkSquare(allSquares, xCoord + i, yCoord + j, font, color, squaresLeft);
                }
            }
        }
    }

}

// This function checks if there are any mines around a certain square
bool minesAround(Square squares[][N], int xIndex, int yIndex, int xMax, int yMax){
    for (int i = -1; i <= 1; i++){
        for (int j = -1; j <= 1; j++){
            if (validCoord(xIndex + i, yIndex + j, xMax, yMax) && !(i == 0 && j == 0)){
                if (squares[xIndex + i][yIndex + j].value == -1){
                    return true;
                }
            }
        }
    }
    return false;
}
