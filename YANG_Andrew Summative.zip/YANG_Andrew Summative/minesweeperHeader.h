/******************************************************
* Name: Andrew Yang                                   *
* Course: ICS3U                                       *
* Teacher: Ms. Cullum                                 *
* Date: December 4 2017                               *
*                                                     *
* This header file contains all the important structs *
* and functions used in the minesweeper game.         *
*******************************************************/

#ifndef MINESWEEPERHEADER_H_INCLUDED
#define MINESWEEPERHEADER_H_INCLUDED

#define WHITE	 al_map_rgb(255, 255, 255)
#define BLACK	 al_map_rgb(0, 0, 0)

const int N = 10;

// Declaring Structures
struct Point{
    int xCoord;
    int yCoord;
};

struct Square{
    Point topLeft;
    int value;
    bool isChecked;
    bool isMarked;
};

// Prototyping Functions
int loadMainMenu(int SCREEN_W, int SCREEN_H);
int loadGame(int rowLength, int columnLength, Square squares[][N], int numOfMines);
int loadMines(int rowLength, int columnLength, Square squares[][N], int numOfMines);
void loadMineCheck(int rowLength, int columnLength, Square squares[][N]);
void mineCheck(Square &homeSquare, Square &checkSquare);
bool validCoord(int xCoord, int yCoord, int xMax, int yMax);
char numToChar(int num);
void checkSquare(Square allSquares[][N], int xCoord, int yCoord, const ALLEGRO_FONT* font, ALLEGRO_COLOR color, int &squaresLeft);
bool minesAround(Square squares[][N], int xIndex, int yIndex, int xMax, int yMax);

#endif // MINESWEEPERHEADER_H_INCLUDED
