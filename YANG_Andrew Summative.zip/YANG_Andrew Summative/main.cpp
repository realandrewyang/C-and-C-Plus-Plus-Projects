/****************************************************
* Name: Andrew Yang                                 *
* Course: ICS3U                                     *
* Teacher: Ms. Cullum                               *
* Date: December 4 2017                             *
* Program Name: Minesweeper                         *
*                                                   *
* This program is a minesweeper game. It includes   *
* flagging, instructions, and a time score.         *
*****************************************************/

/********************************************
* "xCoord and yCoord" are sometimes used    *
* to refer to the x-Index and the y-Index.  *
*********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <allegro5/allegro.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_native_dialog.h>
#include <allegro5/mouse.h>
#include "minesweeperHeader.h"
#include "minesweeperModule.cpp"

const int SCREEN_W = 280;
const int topLeftX = 40;
const int SCREEN_H = 280;
const int topLeftY = 40;

int main(){

    // Declare and initialize pointers and variables
    ALLEGRO_DISPLAY *display = nullptr;
    ALLEGRO_EVENT_QUEUE *event_queue = nullptr;
    ALLEGRO_MOUSE_STATE mouse_position;

    int errorCheck = 0;
    int currentTopLeftX = 0;
    int currentTopLeftY = 0;
    int squaresLeft = 10 * 10;
    int numOfMines = 10;
    int initialTime = 0;
    char currentTime[5] = "";
    char winMessage[30] = "You won in ";
    int winTime = 0;
    char squareValue[2] = "";
    Square mySquares[10][10];

    // Randomize timer
    srand(time(0));

    // Initialize mines
    for (int i = 0; i < 10; i++){
        for (int j = 0; j < 10; j++){
            mySquares[i][j].isChecked = false;
            mySquares[i][j].isMarked = false;
            mySquares[i][j].value = 0;
        }
    }

    // Load mines and numbers
    loadMines(10, 10, mySquares, numOfMines);
    loadMineCheck(10, 10, mySquares);

    // Initialize Allegro
    al_init();
    al_init_font_addon(); // initialize the font addon
    al_init_ttf_addon(); // initialize the ttf (True Type Font) addon
    al_install_mouse(); // install mouse driver

    // Load Main Menu
    errorCheck = loadMainMenu(2 * SCREEN_W, 2 * SCREEN_H);

    // End program if user exits main menu
    if (errorCheck == 2){
        return 2;

    }

    // Initialize display
	display = al_create_display(SCREEN_W, SCREEN_H);
	if (!display) {
    	al_show_native_message_box(display, "Error", "Error", "Failed to initialize display!",
                                 nullptr, ALLEGRO_MESSAGEBOX_ERROR);
       	return -1;
	}

    // Initialize primitive add on
    al_set_window_title(display, "Minesweeper");
 	if (!al_init_primitives_addon()) {
    	al_show_native_message_box(display, "Error", "Error", "Failed to initialize primatives addon!",
                                 nullptr, ALLEGRO_MESSAGEBOX_ERROR);
    	return -1;
	}

	// Load font
    ALLEGRO_FONT *otherFont = al_load_ttf_font("COURIER.TTF", 18, 0);
    if (!otherFont){
        al_show_native_message_box(display, "Error", "Error", "Could not load COURIER.TTF",
                                     nullptr, ALLEGRO_MESSAGEBOX_ERROR);
        return -1;
    }

	// Load board
	for (int i = 0; i < 10; i++){
        for (int j = 0; j < 10; j++){
            // Set the top left coordinates for the square
            currentTopLeftX = topLeftX + j * 20;
            currentTopLeftY = topLeftY + i * 20;
            mySquares[i][j].topLeft.xCoord = topLeftX + j * 20;
            mySquares[i][j].topLeft.yCoord = topLeftY + i * 20;
            al_draw_rectangle(currentTopLeftX, currentTopLeftY, currentTopLeftX + 20, currentTopLeftY + 20, WHITE, 1);
        }
	}

	// Create event queue and register event sources
    event_queue = al_create_event_queue();
    al_register_event_source(event_queue, al_get_mouse_event_source());
    al_register_event_source(event_queue, al_get_display_event_source(display));

    if(!event_queue) {
        al_show_native_message_box(display, "Error", "Error", "Failed to create event queue!",
                                nullptr, ALLEGRO_MESSAGEBOX_ERROR);
    	return -1;
    }

	// display what has been drawn
  	al_flip_display();

  	// Initialize time
    initialTime = time(0);

    // Keep the game going until there are fewer squares left than mines
	while (squaresLeft > numOfMines){

        // Variables i and j are used here as the x-index and y-index
        int i = 0;
        int j = 0;

        // Create event queue
        ALLEGRO_EVENT ev;
        al_wait_for_event(event_queue, &ev);

        // Check if click occurs
        if (ev.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN){

            // Get indices
            al_get_mouse_state(&mouse_position);
            j = (mouse_position.x - topLeftX) / 20;
            i = (mouse_position.y - topLeftY) / 20;

            // Check if indices are valid
            if (i >= 0 && i < 10 && j >= 0 && j < 10){

                /* Reveal the square if the left button is pressed down onto an unmarked square,
                   and mark or unmark a square if the right button is pressed down onto an unknown square */
                if (mouse_position.buttons & 1 && !mySquares[i][j].isMarked){
                    if (!mySquares[i][j].isChecked){
                        checkSquare(mySquares, i, j, otherFont, WHITE, squaresLeft);
                    }
                } else if (mouse_position.buttons & 2 && !mySquares[i][j].isChecked){
                    mySquares[i][j].isMarked = !mySquares[i][j].isMarked;

                    // Recolour the square accordingly if it is marked or unmarked
                    if (mySquares[i][j].isMarked){
                        al_draw_filled_circle(mySquares[i][j].topLeft.xCoord + 10, mySquares[i][j].topLeft.yCoord + 10, 5, WHITE);
                    } else {
                        al_draw_filled_rectangle(mySquares[i][j].topLeft.xCoord + 2, mySquares[i][j].topLeft.yCoord + 2, mySquares[i][j].topLeft.xCoord + 18, mySquares[i][j].topLeft.yCoord + 18, BLACK);
                    }
                }
            }
        } else if (ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE){

            // Close program
            al_destroy_display(display);
        }
        al_flip_display();
	}

	// Generate win message
    sprintf(currentTime,"%d", time(0) - initialTime);
    strncat(winMessage, currentTime, 12);
    strncat(winMessage, " seconds!", 12 + strlen(currentTime));

	// Display Game Over message if user hit a mine and the Win message if user wins
	if (squaresLeft == -1){
        al_show_native_message_box(display, "Game Over", "Game Over", "You hit a mine!",
                                 nullptr, ALLEGRO_MESSAGEBOX_ERROR);
        return -1;
	} else {
        al_show_native_message_box(display, "Win", "Congratulations!", winMessage,
                                 nullptr, ALLEGRO_MESSAGEBOX_OK_CANCEL);
	}

	al_destroy_display(display);
    return 0;
}
